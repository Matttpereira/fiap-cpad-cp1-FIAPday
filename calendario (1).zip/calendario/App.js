import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ScrollView,
} from "react-native";

export default function App() {
  const [texto, setTexto] = useState("");
  const [eventos, setEventos] = useState({});
  const [diaSelecionado, setDiaSelecionado] = useState(null);

  function salvarEvento() {
    if (!texto.trim() || !diaSelecionado) return;

    setEventos((prev) => ({
      ...prev,
      [diaSelecionado]: [...(prev[diaSelecionado] || []), texto],
    }));

    setTexto("");
  }

  const dias = Array.from({ length: 31 }, (_, i) => i + 1);
  const lista = eventos[diaSelecionado] || [];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>📅 Março 2026 🚀</Text>

      <View style={styles.grade}>
        {dias.map((dia) => (
          <TouchableOpacity
            key={dia}
            style={[
              styles.dia,
              diaSelecionado === dia && styles.diaSelecionado,
            ]}
            onPress={() => setDiaSelecionado(dia)}
          >
            <Text style={styles.textoDia}>{dia}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.info}>
        {diaSelecionado
          ? `Dia selecionado: ${diaSelecionado}`
          : "Selecione um dia"}
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite um evento"
        placeholderTextColor="#999"
        value={texto}
        onChangeText={setTexto}
      />

      <TouchableOpacity style={styles.botao} onPress={salvarEvento}>
        <Text style={styles.textoBotao}>Salvar</Text>
      </TouchableOpacity>

      {lista.length === 0 ? (
        <Text style={styles.semEvento}>Nenhum evento para este dia</Text>
      ) : (
        lista.map((item, index) => (
          <Text key={index} style={styles.evento}>
            • {item}
          </Text>
        ))
      )}
    </ScrollView>
  );
}

